/*
Package openapiv2 contains the algorithms and data structures used to
generate OpenAPI v2 specifications from Goa designs.
*/
package openapiv2
