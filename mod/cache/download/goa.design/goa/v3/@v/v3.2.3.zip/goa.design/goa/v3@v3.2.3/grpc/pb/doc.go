// Package goapb contains protocol buffer message types used by the code
// generation logic.
package goapb
