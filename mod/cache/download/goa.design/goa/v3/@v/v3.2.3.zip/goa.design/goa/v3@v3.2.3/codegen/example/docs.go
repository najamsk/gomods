// Package example contains code generation algorithms to produce an example
// server and client implementation for the transports defined in the design.
package example
