package aliasd

type ConvertModel struct {
	Bar string
}
