/*
Package openapiv3 contains the algorithms and data structures used to
generate OpenAPI v3 specifications from Goa designs.
*/
package openapiv3
