// Package service contains the code generation algorithms to produce code for
// the service and views packages and dummy implementation for the services
// defined in the design.
package service
