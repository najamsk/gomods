/*
Package openapi provides common algorithms and data structures used to
generate both OpenAPI v2 and v3 specifications from Goa designs.
*/
package openapi
