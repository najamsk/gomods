/*Package codegen contains code generation logic to generate HTTP server and
client that wrap the generated goa endpoint and the OpenAPI 2.0 specifications
for the HTTP endpoints.
*/
package codegen
