package external

type ConvertModel struct {
	Foo string
}

type MixedCaseModel struct {
	LowerCamelID string
	UpperCamelID string
	SnakeID      string
}
