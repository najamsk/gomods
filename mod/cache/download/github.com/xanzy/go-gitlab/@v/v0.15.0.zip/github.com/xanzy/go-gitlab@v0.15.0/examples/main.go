package main

func main() {
	// See the separate files in this directory for the examples. This file is only
	// here to provide a main() function for the `example` package, keeping Travis happy.
}
