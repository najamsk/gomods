source scripts/lib.sh

ensure_go_binary honnef.co/go/tools/cmd/staticcheck
ensure_go_binary github.com/securego/gosec/cmd/gosec
