---
name: Feature request
about: Suggest an idea for containerd
title: ''
labels: kind/feature
assignees: ''
---

**What is the problem you're trying to solve**
A clear and concise description of what the problem is.

**Describe the solution you'd like**
A clear and concise description of what you'd like to happen.

**Additional context**
Add any other context about the feature request here.