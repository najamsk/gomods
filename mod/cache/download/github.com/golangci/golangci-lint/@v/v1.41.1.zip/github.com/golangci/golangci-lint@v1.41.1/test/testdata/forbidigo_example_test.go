//args: -Eforbidigo
//config_path: testdata/configs/forbidigo.yml
package testdata

import "fmt"

func ExampleForbidigo() {
	fmt.Printf("too noisy!!!") // godoc examples are ignored (in *_test.go files only)
}
