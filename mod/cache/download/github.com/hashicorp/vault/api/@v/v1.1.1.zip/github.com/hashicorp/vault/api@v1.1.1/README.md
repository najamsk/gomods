Vault API
=================

This provides the `github.com/hashicorp/vault/api` package which contains code useful for interacting with a Vault server.

[![GoDoc](https://godoc.org/github.com/hashicorp/vault/api?status.png)](https://godoc.org/github.com/hashicorp/vault/api)