# Changelog

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

## [v8.0.0]

### Changed

- Update code for new randomizer interface
- Start versioning with semantic versions
- Add tags for older versions (back to 7.1.0)
