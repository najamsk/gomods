// +build !gocql_debug

package gocql

const gocqlDebug = false
