// Package pkg ...
package pkg // MATCH /you have exceeded the maximum number of public struct declarations/

type Foo struct {
}

type Bar struct {
}

type Baz struct {
}
