# HttpPath [![Build Status](https://travis-ci.org/dimfeld/httppath.png?branch=master)](https://travis-ci.org/dimfeld/httppath) [![GoDoc](https://godoc.org/github.com/dimfeld/httppath?status.svg)](https://godoc.org/github.com/dimfeld/httppath)

Utilities for HTTP Path manipulation.  

Currently, this just contains the CleanPath function, renamed to Clean, from [Julien Schmidt's httprouter](https://github.com/julienschmidt/httprouter).
