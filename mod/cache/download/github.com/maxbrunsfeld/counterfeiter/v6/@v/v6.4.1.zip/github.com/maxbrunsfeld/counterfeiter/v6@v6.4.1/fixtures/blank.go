package fixtures // import "github.com/maxbrunsfeld/counterfeiter/v6/fixtures"
