package internal

type Context interface {
	DoSomething()
}
