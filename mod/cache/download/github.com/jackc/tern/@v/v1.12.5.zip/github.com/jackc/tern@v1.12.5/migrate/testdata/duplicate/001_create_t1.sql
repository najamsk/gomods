create table t1(
  id serial primary key
);

---- create above / drop below ----

drop table t1;
