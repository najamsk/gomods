drop table t2;
