-- no SQL here
-- nor here, just all comments.
 -- comment with space before
 
---- create above / drop below ----

drop table t1;
