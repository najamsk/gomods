{{ template "add.sql" . }}
{{ template "magic_number.sql" . }}
