create table t1(
  id serial primary key,
  placebo varchar not null
);

---- create above / drop below ----

drop table t1;
