create view v1 as select * from t1;
