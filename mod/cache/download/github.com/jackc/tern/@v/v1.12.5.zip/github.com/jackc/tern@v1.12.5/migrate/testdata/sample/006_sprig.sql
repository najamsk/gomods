create table baz_{{sub 43 1}}(id serial primary key);

---- create above / drop below ----

drop table baz_{{sub 43 1}};
