create view {{.prefix}}v1 as select * from t1;
