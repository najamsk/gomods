create table duplicate(
  id serial primary key
);

---- create above / drop below ----

drop table duplicate;
