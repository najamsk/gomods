package comments

//go:embed data.txt // want `don't use go:embed in _foo files`
