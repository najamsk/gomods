package filtertest

func _() {
	fileTest("with foo prefix") // want `YES`
}
