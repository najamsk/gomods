package filtertest

func typeTest(args ...interface{})         {}
func pureTest(args ...interface{})         {}
func textTest(args ...interface{})         {}
func parensFilterTest(args ...interface{}) {}
func importsTest(args ...interface{})      {}
func fileTest(args ...interface{})         {}
func nodeTest(args ...interface{})         {}

func random() int {
	return 42
}
