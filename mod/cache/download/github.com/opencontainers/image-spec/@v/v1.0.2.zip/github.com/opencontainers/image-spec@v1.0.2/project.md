# Project docs

## Release Process

* `git tag` the prior commit (preferably signed tag)
* Make a release on [github.com/opencontainers/image-spec](https://github.com/opencontainers/image-spec/releases) for the version. Attach the produced docs.

