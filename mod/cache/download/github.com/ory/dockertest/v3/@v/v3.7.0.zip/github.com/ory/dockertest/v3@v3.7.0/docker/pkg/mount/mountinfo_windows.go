package mount // import "github.com/ory/dockertest/v3/docker/pkg/mount"

func parseMountTable() ([]*Info, error) {
	// Do NOT return an error!
	return nil, nil
}
