package opts

type Parser struct {
	UsePositionalParameters bool
	Debug                   Debug
}
