package ast

type OnConflictAction uint

func (n *OnConflictAction) Pos() int {
	return 0
}
