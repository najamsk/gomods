package ast

type AggSplit uint

func (n *AggSplit) Pos() int {
	return 0
}
