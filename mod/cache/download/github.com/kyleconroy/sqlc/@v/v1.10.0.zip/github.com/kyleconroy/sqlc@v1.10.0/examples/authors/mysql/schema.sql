CREATE TABLE authors (
          id   BIGINT PRIMARY KEY AUTO_INCREMENT,
          name text      NOT NULL,
          bio  text
);
