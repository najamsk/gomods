package ast

type CoercionForm uint

func (n *CoercionForm) Pos() int {
	return 0
}
