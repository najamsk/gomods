package ast

type RoleStmtType uint

func (n *RoleStmtType) Pos() int {
	return 0
}
