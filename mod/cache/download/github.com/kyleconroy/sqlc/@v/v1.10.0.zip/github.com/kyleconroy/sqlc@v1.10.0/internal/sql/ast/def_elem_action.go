package ast

type DefElemAction uint

func (n *DefElemAction) Pos() int {
	return 0
}
