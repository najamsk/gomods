Database and Language Support
#############################

========  ============  ============
Language  MySQL         PostgreSQL
========  ============  ============
Go        Stable        Stable
Kotlin    Beta          Beta
Python    Experimental  Experimental
========  ============  ============

Future Language Support
************************

- `C# <https://github.com/kyleconroy/sqlc/issues/373>`_
- `TypeScript <https://github.com/kyleconroy/sqlc/issues/296>`_

Future Database Support
************************

- `SQLite <https://github.com/kyleconroy/sqlc/issues/161>`_
