package ast

type OnCommitAction uint

func (n *OnCommitAction) Pos() int {
	return 0
}
