package ast

type A_Expr_Kind uint

func (n *A_Expr_Kind) Pos() int {
	return 0
}
