CREATE TABLE city (
    slug varchar(255) PRIMARY KEY,
    name text NOT NULL
)
