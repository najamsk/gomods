package ast

type PartitionRangeDatumKind uint

func (n *PartitionRangeDatumKind) Pos() int {
	return 0
}
