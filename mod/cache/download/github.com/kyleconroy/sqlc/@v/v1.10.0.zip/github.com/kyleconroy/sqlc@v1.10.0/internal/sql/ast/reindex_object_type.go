package ast

type ReindexObjectType uint

func (n *ReindexObjectType) Pos() int {
	return 0
}
