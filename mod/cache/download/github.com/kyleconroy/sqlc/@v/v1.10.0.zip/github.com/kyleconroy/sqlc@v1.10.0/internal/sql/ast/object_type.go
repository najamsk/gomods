package ast

type ObjectType uint

func (n *ObjectType) Pos() int {
	return 0
}
