package ast

type RTEKind uint

func (n *RTEKind) Pos() int {
	return 0
}
