package ast

type ConstrType uint

func (n *ConstrType) Pos() int {
	return 0
}
