package ast

type RowCompareType uint

func (n *RowCompareType) Pos() int {
	return 0
}
