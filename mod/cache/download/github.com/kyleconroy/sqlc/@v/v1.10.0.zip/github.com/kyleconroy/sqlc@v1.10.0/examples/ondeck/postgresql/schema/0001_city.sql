CREATE TABLE city (
    slug text PRIMARY KEY,
    name text NOT NULL
)
