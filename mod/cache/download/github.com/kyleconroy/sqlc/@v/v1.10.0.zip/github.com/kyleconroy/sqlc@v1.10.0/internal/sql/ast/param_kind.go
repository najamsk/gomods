package ast

type ParamKind uint

func (n *ParamKind) Pos() int {
	return 0
}
