/** COPY from https://github.com/zentures/cityhash/

NOTE: The code is modified to be compatible with CityHash128 used in ClickHouse
*/
package cityhash102
