// Package options contains configuration options
// including command line flags
package options

var BuiltDate string
var Client bool
