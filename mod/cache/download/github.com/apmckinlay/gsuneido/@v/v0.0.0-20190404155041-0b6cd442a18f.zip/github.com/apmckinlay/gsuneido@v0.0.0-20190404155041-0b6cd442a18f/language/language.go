// Package language contains tests
// need this file to avoid "no non-test files"
// Can't put these tests in runtime because of import cycle with compile.
package language
