// Package bits provides bit manipulation functions
package bits
