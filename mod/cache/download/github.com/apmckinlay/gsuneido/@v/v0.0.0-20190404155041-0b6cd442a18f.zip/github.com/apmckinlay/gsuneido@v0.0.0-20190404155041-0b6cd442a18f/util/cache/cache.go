// Package cache provides a template for a simple LRU cache
// need this file to avoid "no non-test files"
package cache
