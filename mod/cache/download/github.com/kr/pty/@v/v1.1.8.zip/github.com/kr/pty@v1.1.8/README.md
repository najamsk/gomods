# pty

This Go module has moved to <https://github.com/creack/pty>.

Existing clients will continue to work.

New clients should use the new module import path
`github.com/creack/pty`.

