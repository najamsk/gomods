// Package jsonresultset is a benchmark for large json result sets
//
// This exists to mitigate "no non-test Go files" in the latest Go
package jsonresultset

func main() {
}
