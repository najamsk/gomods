/*Package codescan provides a scanner for go files that produces a swagger spec document.

This package is intendnd for go1.11 onwards, and does support go modules.
*/
package codescan
