#!/bin/bash
#

# Per-instance Go kafkatest client dependency deployment.
# Installs required dependencies.

sudo apt-get install -y libsasl2 libsasl2-modules-gssapi-mit libssl1.1.0 liblz4-1
