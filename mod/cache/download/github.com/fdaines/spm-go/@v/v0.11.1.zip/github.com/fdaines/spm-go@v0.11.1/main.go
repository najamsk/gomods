package main

import (
	"github.com/fdaines/spm-go/cmd"
)

func main() {
	cmd.Execute()
}
