package common

var OutputFormat string
var Verbose bool
var HtmlOutput bool
