DROP INDEX IF EXISTS users_email_index;
