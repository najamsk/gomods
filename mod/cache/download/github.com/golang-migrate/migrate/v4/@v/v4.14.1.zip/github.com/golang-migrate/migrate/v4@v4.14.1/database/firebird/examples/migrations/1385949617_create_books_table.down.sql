DROP TABLE books;
