package x

// import bar "github.com/nishanths/exhaustive/testdata/playground/y"
