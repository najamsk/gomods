package types

const (
	NameEmpty  = "empty"
	NameAnon   = "anon"
	NameError  = "error"
	NameStdLib = "stdlib"
)
