package main

func foo() {
	var x map[int]int

	_, ok := x[123]
	println()
	println()
	println()
	println()
	println()
	println()
	println(ok)
}
