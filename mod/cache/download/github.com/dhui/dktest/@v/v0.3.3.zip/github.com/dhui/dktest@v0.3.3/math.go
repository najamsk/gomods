package dktest

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
