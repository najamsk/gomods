// +build ddebug

package decimal

const debug = true
