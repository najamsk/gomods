// +build ppc64le ppc64 amd64p32 s390x arm64 mips64 mips64le amd64

package c

const MaxScale = 999999999999999999
const MaxScaleInf = 2000000000000000001
