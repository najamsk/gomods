// Package sql provides the ability to use Big decimals with SQL databases.
//
// Deprecated: With the addition of the "decimal" interface (see: https://golang.org/issue/30870),
// none of these subpackages are needed. They may be removed in a future version.
package sql
