// Package math implements various useful mathematical functions and constants.
package math
