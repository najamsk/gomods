// +build !ddebug

package decimal

const debug = false
