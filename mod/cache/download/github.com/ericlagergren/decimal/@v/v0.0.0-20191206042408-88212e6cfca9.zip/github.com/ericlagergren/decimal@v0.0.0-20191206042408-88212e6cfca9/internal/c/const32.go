// +build js 386 mips mipsle arm

package c

const MaxScale = 425000000
const MaxScaleInf = 1000000001
