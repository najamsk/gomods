package point

type Point struct {
	X, Y int
}
