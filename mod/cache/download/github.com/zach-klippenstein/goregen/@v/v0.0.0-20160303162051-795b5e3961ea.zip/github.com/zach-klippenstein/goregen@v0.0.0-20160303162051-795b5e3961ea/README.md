#goregen [![GoDoc](https://godoc.org/github.com/zach-klippenstein/goregen?status.svg)](https://godoc.org/github.com/zach-klippenstein/goregen) [![Build Status](https://travis-ci.org/zach-klippenstein/goregen.svg?branch=master)](https://travis-ci.org/zach-klippenstein/goregen)

A Golang library for generating random strings from regular expressions.

Checkout https://goregen-demo.herokuapp.com for a live demo.

See the [godoc](https://godoc.org/github.com/zach-klippenstein/goregen) for examples.
