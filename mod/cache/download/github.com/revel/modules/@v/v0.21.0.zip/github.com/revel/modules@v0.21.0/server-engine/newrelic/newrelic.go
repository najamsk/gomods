package revelnewrelic

// Required for vendoring see golang.org/issue/13832
