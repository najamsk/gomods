package command
type (
	Clean struct {
		ImportCommand
	}
)
