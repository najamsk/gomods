// This is free and unencumbered software released into the public
// domain.  For more information, see <http://unlicense.org> or the
// accompanying UNLICENSE file.

// Package types contains logic for parsing type definitions from ast
// packages and filtering those types.
package types

//go:generate hel
