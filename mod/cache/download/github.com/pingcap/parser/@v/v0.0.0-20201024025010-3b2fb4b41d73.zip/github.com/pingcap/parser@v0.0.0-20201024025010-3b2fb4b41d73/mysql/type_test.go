// Copyright 2015 PingCAP, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// See the License for the specific language governing permissions and
// limitations under the License.

package mysql

import (
	. "github.com/pingcap/check"
)

var _ = Suite(&testTypeSuite{})

type testTypeSuite struct{}

func (s *testTypeSuite) TestFlags(c *C) {
	c.Assert(HasNotNullFlag(NotNullFlag), IsTrue)
	c.Assert(HasUniKeyFlag(UniqueKeyFlag), IsTrue)
	c.Assert(HasNotNullFlag(NotNullFlag), IsTrue)
	c.Assert(HasNoDefaultValueFlag(NoDefaultValueFlag), IsTrue)
	c.Assert(HasAutoIncrementFlag(AutoIncrementFlag), IsTrue)
	c.Assert(HasUnsignedFlag(UnsignedFlag), IsTrue)
	c.Assert(HasZerofillFlag(ZerofillFlag), IsTrue)
	c.Assert(HasBinaryFlag(BinaryFlag), IsTrue)
	c.Assert(HasPriKeyFlag(PriKeyFlag), IsTrue)
	c.Assert(HasMultipleKeyFlag(MultipleKeyFlag), IsTrue)
	c.Assert(HasTimestampFlag(TimestampFlag), IsTrue)
	c.Assert(HasOnUpdateNowFlag(OnUpdateNowFlag), IsTrue)
}
