package here

import (
	"github.com/gobuffalo/here"
)

type Info = here.Info
type Module = here.Module
type Path = here.Path

var Dir = here.Dir
var Package = here.Package
var Current = here.Current
