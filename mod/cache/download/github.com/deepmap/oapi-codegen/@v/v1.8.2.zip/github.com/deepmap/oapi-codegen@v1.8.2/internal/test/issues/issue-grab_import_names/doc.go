package grab_import_names

//go:generate go run github.com/deepmap/oapi-codegen/cmd/oapi-codegen  --package=grab_import_names -o issue.gen.go spec.yaml
