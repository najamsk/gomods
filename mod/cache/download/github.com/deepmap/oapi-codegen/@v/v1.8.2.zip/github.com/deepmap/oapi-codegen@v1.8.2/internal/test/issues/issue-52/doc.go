package issue_52

//go:generate go run github.com/deepmap/oapi-codegen/cmd/oapi-codegen  --package=issue_52 -o issue.gen.go spec.yaml
