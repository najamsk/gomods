package illegal_enum_names

//go:generate go run github.com/deepmap/oapi-codegen/cmd/oapi-codegen  --package=illegal_enum_names -o issue.gen.go spec.yaml
