// +build tools

package tools

import (
	_ "github.com/cyberdelia/templates"
	_ "github.com/matryer/moq"
)
