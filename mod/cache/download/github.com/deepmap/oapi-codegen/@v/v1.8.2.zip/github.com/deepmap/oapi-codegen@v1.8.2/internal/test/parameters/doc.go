package parameters

//go:generate go run github.com/deepmap/oapi-codegen/cmd/oapi-codegen --package=parameters -o parameters.gen.go parameters.yaml
