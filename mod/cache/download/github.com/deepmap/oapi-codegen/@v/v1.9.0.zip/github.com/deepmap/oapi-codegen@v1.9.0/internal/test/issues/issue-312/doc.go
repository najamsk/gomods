package issue_312

//go:generate go run github.com/deepmap/oapi-codegen/cmd/oapi-codegen --package=issue_312 -o issue.gen.go spec.yaml
