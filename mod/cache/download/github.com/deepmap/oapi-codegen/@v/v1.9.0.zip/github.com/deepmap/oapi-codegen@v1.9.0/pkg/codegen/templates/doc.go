package templates

//go:generate go run github.com/cyberdelia/templates -s . -o templates.gen.go
