package code

var myVar = "global" // want "myVar is a global variable"
