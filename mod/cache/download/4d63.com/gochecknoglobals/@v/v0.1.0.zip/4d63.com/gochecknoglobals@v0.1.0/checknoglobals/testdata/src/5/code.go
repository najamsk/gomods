package code

var myVar1, myVar2 = 1, 2 // want "myVar1 is a global variable" "myVar2 is a global variable"
