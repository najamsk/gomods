lldb
====

Package lldb implements a low level database engine.

Installation: $ go get modernc.org/lldb

Documentation: [godoc.org/modernc.org/lldb](http://godoc.org/modernc.org/lldb)
