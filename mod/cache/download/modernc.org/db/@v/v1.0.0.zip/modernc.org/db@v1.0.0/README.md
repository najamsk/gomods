# db

Package DB implements some data structures found in database implementations. (Work in Progress)

Installation

    $ go get modernc.org/db

Documentation: [godoc.org/modernc.org/db](http://godoc.org/modernc.org/db)
