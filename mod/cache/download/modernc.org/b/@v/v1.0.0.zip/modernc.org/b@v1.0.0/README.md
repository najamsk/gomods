b
=

Package b implements a B+tree.

Installation:

    $ go get modernc.org/b

Documentation: [godoc.org/modernc.org/b](http://godoc.org/modernc.org/b)
