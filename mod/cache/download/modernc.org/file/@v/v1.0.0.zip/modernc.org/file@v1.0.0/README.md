# file

Package file handles write-ahead logs and space management of os.File-like entities.

Installation

    $ go get modernc.org/file

Documentation: [godoc.org/modernc.org/file](http://godoc.org/modernc.org/file)
